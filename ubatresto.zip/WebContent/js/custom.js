$j = jQuery;

function openRegisterForm() {

}

$j(document).ready(function() {
	$j("#register").fancybox({
		'width' : 750,
		'autoDimensions' : false
	});

	$j("#login").fancybox({
		'width' : 300,
		'autoDimensions' : false
	});

	$j('#datetimepicker1').datetimepicker({
		viewMode : 'years',
		format : 'MM/YYYY'
	});

	check_recent_login();
	login_user();
});

function login_user() {

	$("#login_btn")
			.click(
					function() {
						clear_err();
						var proceed = true;
						// simple validation at client's end
						// loop through each field and we simply change border
						// color to red for invalid fields
						$(
								"#login_form input[required], #login_form textarea[required]")
								.each(
										function() {
											$(this).css('background-color', '');
											if (!$.trim($(this).val())) { // if
												// this
												// field
												// is
												// empty
												$(this).css('background-color',
														'#FFDEDE'); // change
												// border
												// color to
												// #FFDEDE
												proceed = false; // set do
												// not
												// proceed
												// flag
											}
											// check invalid email
											var email_reg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
											if ($(this).attr("type") == "email"
													&& !email_reg
															.test($
																	.trim($(
																			this)
																			.val()))) {
												$(this).css('background-color',
														'#FFDEDE'); // change
												// border
												// color to
												// #FFDEDE
												proceed = false; // set do
												// not
												// proceed
												// flag
											}
										});

						if (proceed) // everything looks good! proceed...
						{

							$j
									.ajax({
										type : 'post',
										dataType : 'json',
										data : $j("#login_form").serialize(),
										url : '/ubatresto/home?action=login_user',
										success : function(data) {
											if (data.error == 0) {
												location.reload();
											} else {
												if (typeof data.login_name != "undefined") {
													$j("#login_form_login_name")
															.css(
																	'background-color',
																	'#FFDEDE');
													$j(
															"#login_form_login_name_err")
															.html(
																	data.login_name);
												}
												if (typeof data.password != "undefined") {
													$j(
															"#login_form_password_err")
															.css(
																	'background-color',
																	'#FFDEDE');
													$j(
															"#login_form_password_err")
															.html(data.password);
												}
											}
										},
										error : function(data) {
											console.log("error");
										},
									});
						}
					});
}

function register_user() {
	// var form_data = {};
	// jQuery('#register_form :input').each(function() {
	// form_data[jQuery(this).attr('name')] = jQuery(this).value;
	// });

	$j.ajax({
		type : 'post',
		dataType : 'json',
		data : $j("#register_form").serialize(),
		url : '/ubatresto/home?action=register_user',
		success : function(data) {
			if (data.error == 0) {
				location.reload();
			}
		},
		error : function(data) {

		},
	});

	return false;
}

function check_recent_login() {

	if ($j.cookie("login_message") && $j.cookie("login_message") != "null") {

		setTimeout(function() {
			$j("#menu_href").trigger("click");
			$j.fancybox({
				content : '<div>' + $j.cookie("login_message") + '</div>'
			});
			$j.cookie("login_message", null);
		}, 2000);
	}
}

function clear_err() {
	$j(".field-error").each(function() {
		$j(this).html("");
	});
}

function addToOrder(btn, item_id) {
	var data_obj = {
		"item_id" : item_id,
		"quantity" : $j("#qty_" + item_id).val(),
		"price" : $j("#price_" + item_id).val(),
	};

	$j.ajax({
		type : 'post',
		dataType : 'json',
		data : data_obj,
		url : '/ubatresto/order?action=additem',
		success : function(data) {
			console.log("success");
			$j("#item_count").html(" ( " + data.total_item + " ) ");
			var items_html = data.item_html;
			show_order_items(items_html);
			if (data.error == 0) {
				// location.reload();
			}
		},
		error : function(data) {
			console.log("error");
		},
	});
	console.log(data);

}

function load_items() {
	$j.ajax({
		type : 'post',
		dataType : 'json',
		data : {
			id : "1"
		},
		url : '/ubatresto/order?action=showitems',
		success : function(data) {
			console.log("success");
			var items_html = data.item_html;
			show_order_items(items_html);
			if (data.error == 0) {
				// location.reload();
			}
		},
		error : function(data) {
			console.log("error");
		},
	});
}

function show_order_items(html) {
	$j.fancybox({
		'width' : 500,
		content : '<div>' + html + '</div>'
	});
}

function removeItem(id, name) {
	var msg_str = "Are you sure you wanna remove " + name
			+ " from your order ?";

	var r = confirm(msg_str);
	if (r == true) {
		$j.ajax({
					type : 'post',
					dataType : 'json',
					data : {
						id : id
					},
					url : '/ubatresto/order?action=removeitem',
					success : function(data) {
						if (data.error == 0) {
							console.log("item_row_" + id);
							$j("#item_row_" + id).remove();
							var item_count = 0;
							$j(".order_item_row").each(function() {
								item_count++;
							});
							if (item_count == 0) {
								$j("#place_order_btn").remove();
								$j("#item_table_body")
										.html(
												"<tr><td colspan='5'> No Item added to Order.</td></tr>");
							}
							if (data.total_item == "") {
								$j("#item_count").html("");
							} else{}
								$j("#item_count").html(
										" ( " + data.total_item + " ) ");
						}
						
					},
					error : function(data) {
						console.log("error");
					},
				});

	} else {
		txt = "You pressed Cancel!";
	}
}


function forwardOrder(order_id,stage){
	$j.ajax({
		type : 'post',
		dataType : 'json',
		data : {
			stage : stage,
			order_id : order_id,
		},
		url : '/ubatresto/order?action=placeorder',
		success : function(data) {
			console.log("success");
			
		},
		error : function(data) {
			console.log("error");
		},
	});
}