-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2016 at 06:18 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resto`
--

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `code` varchar(5) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` float NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `cooking_minutes` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `type_id`, `code`, `name`, `price`, `description`, `image`, `cooking_minutes`) VALUES
(1, 1, 'MS', 'Mozzarella Sticks', 6.99, 'Mozzarella sticks are elongated pieces of battered or breaded mozzarella. ', 'images/ms.jpeg', 10),
(2, 1, 'OR', 'Onion Rings', 3.99, 'Onion rings are a form of appetizer or side dish commonly found in the United States', 'images/or.jpeg', 10),
(3, 1, 'OM', 'Omelette', 7.99, 'In cuisine, an omelette or omelet is a dish made from beaten eggs', 'images/om.jpeg', 15),
(4, 1, 'CN', 'Chicken Nuggets', 9.99, 'A chicken nugget is a chicken product made from either meat slurry or chicken breasts', 'images/cn.jpeg', 20),
(5, 2, 'CC', 'Chicken Curry', 19.99, 'Chicken curry is a common delicacy in South Asia, Southeast Asia', 'images/cc.jpeg', 30),
(6, 2, 'MK', 'Malai Kofta', 16.99, 'Kofta is a family of meatball or meatloaf dishes found in South Asian', 'images/mk.jpeg', 20),
(7, 2, 'PP', 'Pepperoni Pizza', 15.99, 'Pizza is a flatbread generally topped with tomato sauce and cheese', 'images/pp.jpeg', 15),
(8, 2, 'CB', 'Chicken Biryani', 15.99, 'Biryani sometimes known as biriyani or biriani, is a mixed rice dish ', 'images/cb.jpeg', 20),
(9, 2, 'MV', 'Mix Vegetable', 17.99, 'Mixed Vegetables also known as Mix Vegetable, is a romance manga', 'images/mv.jpeg', 15),
(10, 3, 'JD', 'Jack Daniels', 9.99, '50ml Tennessee whiskey', 'images/jd.jpeg', 5),
(11, 3, 'JWB', 'Johnny Walker Black', 11.99, '50ml Scotch Whiskey ', 'images/jwb.jpeg', 5),
(12, 3, 'JWR', 'Johnny Walker Red', 10.99, '50ml Scotch Whiskey', 'images/jwr.jpeg', 5),
(13, 3, 'JWDB', 'Johnny Walker Double Black', 13.99, '50ml Scotch Whiskey', 'images/jwdb.jpeg', 5),
(14, 3, 'CR', 'Chivas Regal', 13.99, '50ml Whiskey', 'images/cr.jpeg', 5),
(15, 4, 'IC', 'Ice-cream', 5.99, 'Ice cream is a sweetened frozen food typically eaten as a snack or dessert', 'images/ic.jpeg', 5),
(16, 4, 'GJ', 'Gulaab Jamun', 1.99, '1Pc Gulab jamun or Gulaab jamun, is a milk-solids-based sweet mithai', 'images/gj.jpeg', 5),
(17, 4, 'RM', 'Ras Malai', 2.99, '1Pc Ras malai or rossomalai is a dessert consumed mainly in India', 'images/rm.jpeg', 5),
(18, 4, 'GKH', 'Gazar Ka Halwa', 5.99, 'Gajar ka halwa also known as gajrela, is a sweet dessert pudding', 'images/gkh.jpeg', 5),
(19, 4, 'MKL', 'Motichoor Laddu', 1.99, '1Pc Laddu or laddoo are ball-shaped sweets popular in the Indian Subcontinent', 'images/mkl.jpeg', 5),
(20, 1, 'FRY', 'French Fries', 4.99, 'French fries (American English), chips, fries, finger chips, or French-fried potatoes', 'images/ff1.jpeg', 10);

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` float NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `is_ready` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order_item_type`
--

CREATE TABLE `order_item_type` (
  `id` int(11) NOT NULL,
  `code` varchar(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `images` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_item_type`
--

INSERT INTO `order_item_type` (`id`, `code`, `name`, `images`) VALUES
(1, 'APT', 'Appetizers', 'images/snacks.jpg'),
(2, 'MC', 'Main Course', 'images/meals.jpg'),
(3, 'BVG', 'Bevrages', 'images/drinks.jpg'),
(4, 'PUD', 'Dessert', 'images/desserts.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `order_queue`
--

CREATE TABLE `order_queue` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order_status`
--

CREATE TABLE `order_status` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `status_id` varchar(255) NOT NULL,
  `remark` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE `order_table` (
  `id` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `no_of_people` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_table`
--

INSERT INTO `order_table` (`id`, `number`, `no_of_people`) VALUES
(1, 1, 2),
(2, 2, 3),
(3, 3, 4),
(4, 4, 5),
(5, 5, 6),
(6, 6, 2),
(7, 7, 3),
(8, 8, 4),
(9, 9, 5),
(10, 10, 3),
(11, 11, 4),
(12, 12, 4),
(13, 13, 4),
(14, 14, 6),
(15, 15, 6);

-- --------------------------------------------------------

--
-- Table structure for table `resto_order`
--

CREATE TABLE `resto_order` (
  `id` int(11) NOT NULL,
  `table_id` int(11) NOT NULL,
  `is_guest` tinyint(1) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `item_total` float DEFAULT NULL,
  `tax` float DEFAULT NULL,
  `total` float DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `code` varchar(5) NOT NULL,
  `name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `code`, `name`) VALUES
(1, 'PED', 'Pending'),
(2, 'ORD', 'Ordered'),
(3, 'WAIT', 'Waiting'),
(4, 'COMP', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `login_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `user_type` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `gender` varchar(10) NOT NULL DEFAULT 'Male',
  `images` varchar(255) DEFAULT NULL,
  `birth_date` date NOT NULL DEFAULT '1988-10-02',
  `login_ip` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `login_name`, `email`, `first_name`, `last_name`, `user_type`, `password`, `phone`, `gender`, `images`, `birth_date`, `login_ip`) VALUES
(2, 'krutarth', 'kd123@gmail.com', 'Krutarth', 'Doshi', 1, '12345', '1234567890', 'Male', NULL, '1988-10-02', NULL),
(3, 'smit', 'smit123@gmail.com', 'Smit', 'Doshi', 1, '12345', '1234567890', 'Male', NULL, '1988-10-02', NULL),
(4, 'lekhraj', 'lb123@gmail.com', 'Lekhraj', 'Bhadava', 1, '12345', '1234567890', 'Male', NULL, '1988-10-02', '0:0:0:0:0:0:0:1'),
(5, 'sandeep', 'sc123@gmail.com', 'Sandeep', 'Chavali', 2, '12345', '1234567890', 'Male', 'images/chef1.jpeg', '1988-10-02', '0:0:0:0:0:0:0:1'),
(6, 'vinay', 'vp123@gmail.com', 'Vinay', 'Patali', 2, '12345', '1234567890', 'Male', 'images/chef2.jpeg', '1988-10-02', NULL),
(7, 'matt', 'mb123@gmail.com', 'Mathew', 'Bartol', 2, '12345', '1234567890', 'Male', 'images/chef3.jpeg', '1988-10-02', NULL),
(8, 'amit', 'ac123@gmail.com', 'Amit', 'Chauhan', 3, '12345', '1234567890', 'Male', NULL, '1988-10-02', NULL),
(9, 'swapnil', 'ss123@gmail.com', 'Swapnil', 'Sawle', 3, '12345', '1234567890', 'Male', NULL, '1988-10-02', NULL),
(10, 'ajinkya', 'ar123@gmail.com', 'Ajinkya', 'Rahaney', 3, '12345', '1234567890', 'Male', NULL, '1988-10-02', NULL),
(11, 'anurag', 'as123@gmail.com', 'Anurag', 'Suryawanshi', 4, '12345', '1234567890', 'Male', NULL, '1988-10-02', NULL),
(12, 'Kate', 'kw123@gmail.com', 'Kate', 'Winslet', 4, '12345', '1234567890', 'Female', NULL, '1988-10-02', NULL),
(13, 'rachel', 'rg123@gmail.com', 'Rachel', 'Green', 4, '12345', '1234567890', 'Female', NULL, '1988-10-02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_type`
--

CREATE TABLE `user_type` (
  `id` int(11) NOT NULL,
  `code` varchar(5) NOT NULL,
  `name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_type`
--

INSERT INTO `user_type` (`id`, `code`, `name`) VALUES
(1, 'ADMIN', 'Administrator'),
(2, 'CHEF', 'Chef'),
(3, 'WAIT', 'Waiter'),
(4, 'GEN', 'General');

-- --------------------------------------------------------

--
-- Table structure for table `waiter_table`
--

CREATE TABLE `waiter_table` (
  `id` int(11) NOT NULL,
  `table_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `waiter_table`
--

INSERT INTO `waiter_table` (`id`, `table_id`, `user_id`) VALUES
(1, 1, 5),
(2, 2, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_item_type_id` (`type_id`),
  ADD KEY `type_id` (`type_id`);

--
-- Indexes for table `order_item`
--
ALTER TABLE `order_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_item_id_` (`item_id`),
  ADD KEY `order_id_item` (`order_id`);

--
-- Indexes for table `order_item_type`
--
ALTER TABLE `order_item_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_queue`
--
ALTER TABLE `order_queue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_status`
--
ALTER TABLE `order_status`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id_status` (`order_id`),
  ADD KEY `order_status_user` (`user_id`),
  ADD KEY `order_status_status_id` (`status_id`);

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resto_order`
--
ALTER TABLE `resto_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_table_id` (`table_id`),
  ADD KEY `order_user_id` (`user_id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_usr_type` (`user_type`);

--
-- Indexes for table `user_type`
--
ALTER TABLE `user_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `waiter_table`
--
ALTER TABLE `waiter_table`
  ADD PRIMARY KEY (`id`),
  ADD KEY `table_id_idx` (`table_id`),
  ADD KEY `user_id_idx` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order_item`
--
ALTER TABLE `order_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `order_item_type`
--
ALTER TABLE `order_item_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `order_queue`
--
ALTER TABLE `order_queue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `order_status`
--
ALTER TABLE `order_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `order_table`
--
ALTER TABLE `order_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `resto_order`
--
ALTER TABLE `resto_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `user_type`
--
ALTER TABLE `user_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `waiter_table`
--
ALTER TABLE `waiter_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `item`
--
ALTER TABLE `item`
  ADD CONSTRAINT `item_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `order_item_type` (`id`);

--
-- Constraints for table `order_item`
--
ALTER TABLE `order_item`
  ADD CONSTRAINT `order_item_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `resto_order` (`id`),
  ADD CONSTRAINT `order_item_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`);

--
-- Constraints for table `order_status`
--
ALTER TABLE `order_status`
  ADD CONSTRAINT `order_status_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `resto_order` (`id`),
  ADD CONSTRAINT `order_status_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Constraints for table `resto_order`
--
ALTER TABLE `resto_order`
  ADD CONSTRAINT `resto_order_ibfk_1` FOREIGN KEY (`table_id`) REFERENCES `order_table` (`id`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`user_type`) REFERENCES `user_type` (`id`);

--
-- Constraints for table `waiter_table`
--
ALTER TABLE `waiter_table`
  ADD CONSTRAINT `waiter_table_ibfk_1` FOREIGN KEY (`table_id`) REFERENCES `order_table` (`id`),
  ADD CONSTRAINT `waiter_table_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
