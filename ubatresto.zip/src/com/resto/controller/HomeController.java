package com.resto.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;

import com.resto.model.*;

/**
 * Servlet implementation class Home
 */
@WebServlet("/Home")
public class HomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HomeController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getParameter("action");
		if (action == null)
			action = "";
		switch (action) {
		case "logout":
			this.logOut(request, response);
			response.sendRedirect("/ubatresto/home");
			break;
		default:
			HttpSession session = request.getSession();
			if((String) session.getAttribute("total_item") == null){
				session.setAttribute("total_item","0");
			}
			String user_role =  (String) session.getAttribute("user_role");
			if(user_role == null){
				user_role = "GEN";
			}
			System.out.println(user_role);
			String main_page = "index.jsp";
			String user_id = null;
			switch (user_role) {
			case "CHEF":
				main_page = "manage.jsp";
				OrderTable ot = new OrderTable();
				Map<String,String> user = (Map<String,String>) session.getAttribute("user");
				user_id = user.get("id");
				ArrayList<Map<String, String>> table_list = ot.load_waiter_table_list(user_id);
				System.out.println(table_list);
				request.setAttribute("table_list", table_list);
				break;
			case "WAIT":
				main_page = "manage.jsp";
				break;
			default:
				break;
			}
			Item order_item_model = new Item();
			ArrayList<Map<String, Object>> food_menu = order_item_model.get_all_items();
			request.setAttribute("food_menu", food_menu);
			request.getRequestDispatcher("/WEB-INF/jsp/"+main_page).forward(request, response);
			break;
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		if (request.getParameter("chat") != null) 
            this.chat(request, response);
		
		String action = request.getParameter("action");
		if (action == null)
			action = "list";
		System.out.println("here " + action);
		switch (action) {
		case "register_user":
			this.addUser(request, response);
			break;
		case "login_user":
			this.loginUser(request, response);
			break;
		default:
			break;
		}
	}

	private void logOut(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		session.setAttribute("user", null);
		session.setAttribute("total_item", null);
		session.invalidate();
	}

	private void addUser(HttpServletRequest request, HttpServletResponse response) {
		java.util.Enumeration enu = request.getParameterNames();
		Map<String, String> form_data = new TreeMap<String, String>();
		String login_name = "";
		while (enu.hasMoreElements()) {
			String param_name = (String) enu.nextElement();
			if (param_name.equals("login_name")) {
				login_name = request.getParameter(param_name);
			}
			if (!param_name.equals("action"))
				form_data.put(param_name, request.getParameter(param_name));
		}
		form_data.put("user_type", "4");
		form_data.put("images", "");
		User user = new User();
		Map<String, String> error_data = user.create_user(form_data);

		int error_status = 1;
		if (error_data.get("error_status").equals("0")) {
			// No Error"select * from user where login_name=\""+login_name+"\""
			ArrayList<Map<String, String>> user_data = user
					.getUserDataByQry("select * from user where login_name=\"" + login_name + "\"", true);
			System.out.println(user_data);
			if (user_data.size() == 1) {
				Map<String, String> current_user = user_data.get(0);
				this.createUserSession(current_user, request);
				error_status = 0;
				String welcome_message = "Welcome, " + current_user.get("first_name") + " "
						+ current_user.get("last_name") + " to your UB Restaurant.";
				this.save_cookie("login_message", welcome_message, response, 20);
			}
		}

		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("error", error_status);
			response.setContentType("application/json");
			response.setCharacterEncoding("utf-8");
			response.getWriter().print(jsonObj);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return;
	}

	private void loginUser(HttpServletRequest request, HttpServletResponse response) {

		String login_name = request.getParameter("login_name");
		String password = request.getParameter("password");
		int error_status = 1;
		JSONObject jsonObj = new JSONObject();
		try {
			if (login_name != "" && password != "") {

				User user = new User();
				ArrayList<Map<String, String>> user_data = user
						.getUserDataByQry("select * from user where login_name=\"" + login_name + "\"", true);
				if (user_data.size() == 1) {
					Map<String, String> current_user = user_data.get(0);
					String user_data_password = current_user.get("password");
					if (user_data_password.equals(password)) {
						this.createUserSession(current_user, request);
						error_status = 0;
						String welcome_message = "Welcome, " + current_user.get("first_name") + " "
								+ current_user.get("last_name") + " to your UB Restaurant.";
						this.load_order_session(current_user.get("id"), request);
						this.save_cookie("login_message", welcome_message, response, 30);
					} else {
						jsonObj.put("password", "Enter Valid Password.");
					}
				} else {
					jsonObj.put("login_name", "User Name Not Found.");
				}
			}

			jsonObj.put("error", error_status);
			response.setContentType("application/json");
			response.setCharacterEncoding("utf-8");
			response.getWriter().print(jsonObj);

		} catch (Exception e) {
			System.out.println(e);
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return;
	}

	public void createUserSession(Map<String, String> user_data, HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = new User();
		ArrayList<Map<String, String>> role_data = user
				.getUserDataByQry("select ut.code from user_type ut join user u on ut.id = u.user_type where "
						+ " u.id=" + user_data.get("id") + ";", true);
		String user_role = null;
		if(role_data.size() > 0){
			user_role = role_data.get(0).get("code");
		}
		String ipAddress = request.getRemoteAddr();  
		user.updateLoginIp(user_data.get("id"), ipAddress);
		session.setAttribute("user", user_data);
		session.setAttribute("user_role", user_role);
	}

	public boolean save_cookie(String name, String value, HttpServletResponse response, int expiryTime) {
		final String cookiePath = "/ubatresto/";
		Cookie myCookie;
		try {
			myCookie = new Cookie(name, URLEncoder.encode(value, "UTF-8"));
			myCookie.setMaxAge(expiryTime);
			myCookie.setPath(cookiePath);
			response.addCookie(myCookie);
			return true;
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

	public void load_order_session(String user_id, HttpServletRequest request) {
		Order order = new Order();
		HttpSession session = request.getSession();
		String order_id = order.load_order_in_session(user_id);
		session.setAttribute("order_id", order_id);
		session.setAttribute("total_item", order.get_order_item_count(order_id));
	}
	private void chat(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException
			{
			String user = request.getParameter("name");
			String ip = java.net.InetAddress.getLocalHost().getHostAddress();
			String realPath = getServletContext().getRealPath("WebContent/img/customer.png");
			File file = new File(realPath);
			String img = "smily";
			if (file.exists())
			img=user;
			request.getRequestDispatcher("/WebContent/chat.jsp?user=" + user +
			"&ip=" + ip + "&img=" + img).forward(request, response);
			} 

}
