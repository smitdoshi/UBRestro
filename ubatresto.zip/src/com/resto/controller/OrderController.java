package com.resto.controller;

import java.io.File;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;

import com.resto.model.*;

/**
 * Servlet implementation class Order
 */
@WebServlet("/Order")
public class OrderController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public OrderController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		String action = request.getParameter("action");
		if (action == null)
			action = "additem";

		switch (action) {
		case "additem":
			this.addItemToOrder(request, response);
			break;
		case "showitems":
			this.getOrderItems(request, response);
			break;
		case "removeitem":
			this.deleteItem(request, response);
			break;
		case "placeorder":
			this.placeOrder(request, response);
			break;
		default:
			break;
		}
	}

	private void addItemToOrder(HttpServletRequest request, HttpServletResponse response) {
		String item_id = request.getParameter("item_id");
		String quantity = request.getParameter("quantity");
		String price = request.getParameter("price");

		HttpSession session = request.getSession();
		String order_id = "0";
		String is_guest = "1";
		Map user_data = null;
		String user_id = Integer.toString((int) (new Date().getTime() / 1000));
		if (session.getAttribute("user") != null) {
			user_data = (Map) session.getAttribute("user");
			user_id = (String) user_data.get("id");
			is_guest = "0";
		}
		
		Order ordr = new Order();
		String table_id = Integer.toString(ordr.get_available_table());
		Map<String, String> order_data = new HashMap<String, String>();
		order_data.put("user_id", user_id);
		order_data.put("table_id", table_id);
		order_data.put("is_guest", is_guest);
		if (session.getAttribute("order_id") != null) {
			order_id = (String) session.getAttribute("order_id");
		} else {
			
			order_data.put("is_guest", is_guest);
			Map<String, String> order_insert = ordr.create_order(order_data);
			System.out.println(order_insert);
			order_id = order_insert.get("order_id");
			session.setAttribute("order_id",order_id);
		}

		order_data.put("item_id", item_id);
		order_data.put("order_id", order_id);
		order_data.put("quantity", quantity);
		order_data.put("price", price);

		Map<String, String> order_item_insert = ordr.add_order_item(order_data);
//		System.out.println(order_item_insert);
		JSONObject jsonObj = new JSONObject();
		try {
			String total_item = ordr.get_order_item_count(order_id);
			String item_html = ordr.get_order_item_html(order_id,true);
			session.setAttribute("total_item", total_item);
			jsonObj.put("error", "0");
			jsonObj.put("total_item", total_item);
			jsonObj.put("item_html", item_html);
			response.setContentType("application/json");
			response.setCharacterEncoding("utf-8");
			response.getWriter().print(jsonObj);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void getOrderItems(HttpServletRequest request, HttpServletResponse response){
		HttpSession session = request.getSession();
		String order_id = (String) session.getAttribute("order_id");
		Order ordr = new Order();
		String item_html = ordr.get_order_item_html(order_id,true);
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("item_html", item_html);
			response.setContentType("application/json");
			response.setCharacterEncoding("utf-8");
			response.getWriter().print(jsonObj);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void deleteItem(HttpServletRequest request, HttpServletResponse response){
		HttpSession session = request.getSession();
		String order_id = (String) session.getAttribute("order_id");
		String order_item_id  = request.getParameter("id");
		Order ordr = new Order();
		ordr.delete_order_item(order_item_id);
		try {
			String total_item = ordr.get_order_item_count(order_id);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("error", "0");
			jsonObj.put("total_item", total_item);
			session.setAttribute("total_item", total_item);
			response.setContentType("application/json");
			response.setCharacterEncoding("utf-8");
			response.getWriter().print(jsonObj);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void placeOrder(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		HttpSession session = request.getSession();
		String order_id = (String) session.getAttribute("order_id");
		String stage  = request.getParameter("stage");
		OrderTable ordrTbl = new OrderTable();
		ordrTbl.set_waiter_table(order_id);
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("error", "0");
			response.setContentType("application/json");
			response.setCharacterEncoding("utf-8");
			response.getWriter().print(jsonObj);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.chat(request, response);
		
	}
	private void chat(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException
			{
			String user = request.getParameter("name");
			String ip = java.net.InetAddress.getLocalHost().getHostAddress();
			String realPath = getServletContext().getRealPath("WebContent/img/customer.png");
			File file = new File(realPath);
			String img = "smily";
			if (file.exists())
			img=user;
			request.getRequestDispatcher("/WebContent/chat.jsp?user=" + user +
			"&ip=" + ip + "&img=" + img).forward(request, response);
			} 

}
