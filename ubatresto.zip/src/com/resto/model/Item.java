package com.resto.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Item extends ModelArchive{

	public ArrayList<Map<String,Object>> get_all_items(){
		ArrayList<Map<String,String>> type_list = this.getKeyValByRow("select * from order_item_type");
		ArrayList<Map<String,Object>> prepared_list = new ArrayList<Map<String,Object>>();
		
		for(Map type : type_list){
			
			String type_id = (String) type.get("id");
			List<Map<String,String>> items = this.getKeyValByRow("select * from item where type_id="+type_id);
			
			int half_count = items.size()/2;
			int first_col_items = 3;
			if(half_count > first_col_items){
				first_col_items = half_count-1;
			}
			int second_col_items = items.size() - first_col_items;
			List<Map<String,String>> col_1 = items.subList(0,first_col_items); 
			List<Map<String,String>> col_2 = items.subList(first_col_items, items.size()); 
//			ArrayList col_arr = new ArrayList();
//			col_arr.add(col_1);
//			col_arr.add(col_2);
			type.put("col_1", col_1);
			type.put("col_2", col_2);
			prepared_list.add(type);
		}
		
		return prepared_list;
	}
}
