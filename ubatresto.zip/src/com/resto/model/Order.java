package com.resto.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.mysql.jdbc.Statement;

public class Order extends ModelArchive {

	public String load_order_in_session(String user_id) {
		String qry = "SELECT ro.id `id` FROM resto_order ro JOIN order_status os ON "
				+ " ro.id=os.order_id WHERE os.status_id NOT LIKE \"Completed\" AND ro.user_id=" + user_id
				+ " ORDER BY ro.id;";
		ArrayList<Map<String, String>> order_list = this.getKeyValByRow(qry);
		String order_id = null;
		if (order_list.size() > 0) {
			order_id = order_list.get(0).get("id");
		}
		return order_id;
	}

	public String get_order_item_count(String order_id) {
		if (order_id == null) {
			return "0";
		}
		String qry = "SELECT SUM(oi.quantity) as total FROM order_item oi "
				+ "JOIN resto_order ro ON ro.id = oi.order_id WHERE " + "ro.id =" + order_id + ";";
		ArrayList<Map<String, String>> item_list = this.getKeyValByRow(qry);

		String count = "0";
		if (item_list.size() > 0) {
			count = item_list.get(0).get("total");
		}
		return count;
	}

	public ArrayList<Map<String, String>> get_order_items(String order_id) {
		if (order_id == null) {
			return new ArrayList<Map<String, String>>();
		}
		String qry = "SELECT oi.id as ID,i.name as NAME,oi.price as PRICE,oi.quantity as QTY,TRUNCATE(oi.price*oi.quantity,2)"
				+ " as ITEM_TOTAL FROM order_item oi JOIN item i ON i.id = oi.item_id " + "WHERE order_id = " + order_id
				+ " ORDER BY i.name;";
		ArrayList<Map<String, String>> item_list = this.getKeyValByRow(qry);

		return item_list;
	}

	public String get_order_item_html(String order_id, boolean load_del_col) {
		String html = "";
		html += "<table class='table table-striped' id='item_table'>";
		html += "<thead><tr>";
		html += "<th  class='Lalgn'>Item</th>";
		html += "<th  class='Ralgn'>Price</th>";
		html += "<th class='Ralgn'>Quantity</th>";
		html += "<th class='Ralgn'>Total</th>";
		if (load_del_col)
			html += "<th class='Ralgn'>Remove</th>";
		else
			html += "<th></th>";
		html += "</tr></thead>";
		html += "<tbody id='item_table_body'>";

		ArrayList<Map<String, String>> item_list = this.get_order_items(order_id);
			
		if (item_list.size() > 0) {
			for (Map item : item_list) {
				String remove_href = "";
				if (load_del_col) {
					remove_href = "<a href='javascript:;' onClick=\"removeItem(" + (String) item.get("id") + ",'"
							+ (String) item.get("name") + "')\" ><i class='glyphicon glyphicon-remove' title='Remove "
							+ (String) item.get("name") + "'></i></a>";
				}
				html += "<tr class='order_item_row' id='item_row_" + (String) item.get("id") + "'>";
				html += "<td class='Lalgn'>" + (String) item.get("name") + "</td>";
				html += "<td class='Ralgn'>" + (String) item.get("price") + "</td>";
				html += "<td class='Ralgn' style=''>" + (String) item.get("quantity") + "</td>";
				html += "<td class='Ralgn'>" + (String) item.get("ITEM_TOTAL") + "</td>";
				html += "<td class='Ralgn'>" + remove_href + "</td>";
				html += "</tr>";
			}
			if (load_del_col) {
				html += "<tr><td colspan='5'> <input type='button' class='btn btn-primary floatR' "
						+ " value='Place order' id='place_order_btn' onClick='forwardOrder("+order_id+",1);'/></td></tr>";
			}
		} else {
			html += "<tr><td colspan='5'> No Item added to Order.</td></tr>";
		}

		html += "</tbody>";
		html += "</table>";
		return html;
	}

	public int get_available_table() {
		String qry = "SELECT order_table.id FROM order_table LEFT OUTER JOIN resto_order ON "
				+ "order_table.id=resto_order.table_id WHERE resto_order.table_id IS NULL ORDER BY order_table.id";
		ArrayList<Map<String, String>> table_list = this.getKeyValByRow(qry);
		return Integer.parseInt(table_list.get(0).get("id"));
	}

	public boolean delete_order_item(String order_item_id) {
		try {
			this.connectToDb();
			this.stmt = this.conn.createStatement();
			this.stmt.executeUpdate("Delete From order_item where id=" + order_item_id);
			this.conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		}
		return true;
	}

	public Map<String, String> create_order(Map<String, String> data) {
		Map<String, String> error_data = new HashMap<String, String>();
		int error = 1;
		String order_id_str = "0";
		try {

			String insert_str = "INSERT INTO resto_order " + "(table_id,is_guest,user_id)" + " values(?,?,?)";
			int param_count = 1;

			this.connectToDb();
			PreparedStatement ps;
			ps = ((java.sql.Connection) this.conn).prepareStatement(insert_str, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, data.get("table_id"));
			ps.setString(2, data.get("is_guest"));
			ps.setString(3, data.get("user_id"));
			ps.execute();
			error = 0;

			ResultSet keys = ps.getGeneratedKeys();
			keys.next();
			int order_id = keys.getInt(1);
			this.conn.close();
			order_id_str = Integer.toString(order_id);
			data.put("order_id", Integer.toString(order_id));
			data.put("status_id", "Pending");

			Map<String, String> order_status_insert = this.add_order_status(data);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		}
		error_data.put("error_status", Integer.toString(error));
		error_data.put("order_id", order_id_str);

		return error_data;
	}

	public Map<String, String> add_order_status(Map<String, String> data) {
		Map<String, String> error_data = new HashMap<String, String>();
		int error = 1;
		try {

			String insert_str = "INSERT INTO order_status " + "(order_id,status_id,user_id,remark)"
					+ " values(?,?,?,?)";

			this.connectToDb();
			PreparedStatement ps;
			ps = ((java.sql.Connection) this.conn).prepareStatement(insert_str, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, data.get("order_id"));
			ps.setString(2, data.get("status_id"));
			ps.setString(3, data.get("user_id"));
			ps.setString(4, data.get("remark"));

			ps.executeUpdate();

			error = 0;
			this.conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		}
		error_data.put("error_status", Integer.toString(error));

		return error_data;
	}

	public Map<String, String> add_order_item(Map<String, String> data) {
		Map<String, String> error_data = new HashMap<String, String>();
		int error = 1;
		try {

			String insert_str = "INSERT INTO order_item " + "(order_id,item_id,quantity,price)" + " values(?,?,?,?)";

			String qry = "SELECT * FROM order_item where order_id=" + data.get("order_id") + " AND item_id="
					+ data.get("item_id") + ";";

			System.out.println(qry);
			ArrayList<Map<String, String>> item_entry = this.getKeyValByRow(qry);

			this.connectToDb();
			PreparedStatement ps;
			if (item_entry.size() > 0) {
				int pre_qty = Integer.parseInt(item_entry.get(0).get("quantity"));
				pre_qty += Integer.parseInt(data.get("quantity"));
				insert_str = "UPDATE order_item SET quantity = ? where order_id=" + data.get("order_id")
						+ " AND item_id=" + data.get("item_id") + ";";

				ps = ((java.sql.Connection) this.conn).prepareStatement(insert_str, Statement.RETURN_GENERATED_KEYS);
				ps.setString(1, Integer.toString(pre_qty));
				ps.executeUpdate();
			} else {
				ps = ((java.sql.Connection) this.conn).prepareStatement(insert_str, Statement.RETURN_GENERATED_KEYS);
				ps.setString(1, data.get("order_id"));
				ps.setString(2, data.get("item_id"));
				ps.setString(3, data.get("quantity"));
				ps.setString(4, data.get("price"));
				ps.executeUpdate();
			}

			error = 0;
			this.conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		}
		error_data.put("error_status", Integer.toString(error));

		return error_data;
	}
}
