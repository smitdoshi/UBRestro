package com.resto.model;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.mysql.jdbc.Statement;

public class OrderTable extends ModelArchive {

	public ArrayList<Map<String, String>> load_waiter_table_list(String user_id) {
		String qry = "SELECT * from order_table ot JOIN waiter_table wt ON wt.table_id = ot.id WHERE wt.user_id="+user_id+";";
		
		ArrayList<Map<String, String>> table_list = this.getKeyValByRow(qry);
		ArrayList<Map<String, String>> list = new ArrayList<Map<String, String>>();
		for(Map table : table_list){
			String table_id = (String) table.get("id");
			
			String tabl_qry = "SELECT * from resto_order ro JOIN order_status os "
					+ "ON os.order_id = ro.id WHERE ro.table_id="+table_id+" AND os.status_id LIKE \"Ordered\" ORDER BY os.id DESC LIMIT 1;";
			
			
			ArrayList<Map<String, String>> order_list = this.getKeyValByRow(tabl_qry);
			
			String order_id = order_list.size() > 0 ? order_list.get(0).get("order_id") : null;
			
			Order ordrObj = new Order();
			table.put("order_html", ordrObj.get_order_item_html(order_id,false));
	
			list.add(table);
		}
		return list;
	}
	
	public void set_waiter_table(String order_id) {
			String qry = "SELECT wt.user_id from resto_order ro JOIN waiter_table wt "
					+ "ON wt.id = ro.table_id WHERE ro.id="+order_id+";";
		ArrayList<Map<String, String>> waiter_list = this.getKeyValByRow(qry);
		
		String user_id = waiter_list.get(0).get("user_id");
		
		Map<String, String> data = new HashMap<String, String>();
		data.put("order_id", order_id);
		data.put("status_id", "Ordered");
		data.put("user_id", user_id);
		data.put("remark", null);
		
		Order order = new Order();
		Map<String, String> order_status_insert = order.add_order_status(data);
		Map<String, String> order_forward_insert = this.forward_order(data);
	}
	
	
	public Map<String, String> forward_order(Map<String, String> data) {
		Map<String, String> error_data = new HashMap<String, String>();
		int error = 1;
		try {

			String insert_str = "INSERT INTO order_queue " + "(order_id,user_id)"
					+ " values(?,?)";

			this.connectToDb();
			PreparedStatement ps;
			ps = ((java.sql.Connection) this.conn).prepareStatement(insert_str, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, data.get("order_id"));
			ps.setString(2, data.get("user_id"));

			ps.executeUpdate();

			error = 0;
			this.conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		}
		error_data.put("error_status", Integer.toString(error));

		return error_data;
	}
}
