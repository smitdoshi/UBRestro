package com.resto.model;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

public class ModelArchive {
	protected Connection conn = null;
	private String url = "jdbc:mysql://localhost/";
	private String dbName = "resto";
	private String driver = "com.mysql.jdbc.Driver";
	private String userName = "root";
	private String password = "";
	protected Statement stmt;
	protected String query;
	private String firstName;
	protected ResultSet rs;
	private int columnCount;
	private String error = "No Error";
	public PreparedStatement ps;

	protected void connectToDb() {
		try {
			Class.forName(this.driver).newInstance();
			this.conn = DriverManager.getConnection(this.url + this.dbName, this.userName, this.password);
		} catch (SQLException ex) {
			System.err.println("\n** SQLException caught **\n");
			this.error = ex.toString();
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();
			this.error = ex.toString();
		}

	}

	protected void setPS(PreparedStatement statement) {
		this.ps = statement;
	}

	public void execQuery(String qry) {
		this.connectToDb();
		ResultSet result = null;
		if (this.error.equals("No Error")) {

			try {
				this.stmt = this.conn.createStatement();
				result = stmt.executeQuery(qry);
				// this.conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				this.error = e.toString();
			}
		}
		this.rs = result;
	}

	public Map<String, ArrayList> getFormattedData(String qry, boolean header_required) {

		ArrayList<String> columns = new ArrayList<String>();
		ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();

		this.execQuery(qry);
		ResultSet result = this.rs;
		System.out.println(this.rs);
		try {
			if (result != null) {
				ResultSetMetaData rsmd = result.getMetaData();
				int getColumnCount = rsmd.getColumnCount();

				for (int i = 1; i <= getColumnCount; i++) {
					columns.add(rsmd.getColumnName(i));
				}
				if (!result.next()) {
					System.out.println("no data");
				} else {

					do {
						ArrayList<String> rowData = new ArrayList<String>();
						for (int i = 1; i <= getColumnCount; i++) {
//							Object col_val = result.getObject(i);
//							rowData.add(col_val.toString());
							Object col_val = result.getObject(i);
							String col_val_str = "";
							if(col_val != null){
								col_val_str = col_val.toString();
							}
							rowData.add(col_val_str);
						}
						data.add(rowData);
					} while (result.next());
				}
			}
			this.conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Map<String, ArrayList> result_data = new HashMap<String, ArrayList>();
		if (header_required)
			result_data.put("column_title", columns);
		result_data.put("rows", data);
		return result_data;
	}
	
	public ArrayList<Map<String,String>> getKeyValByRow(String qry) {

		ArrayList<String> columns = new ArrayList<String>();
		ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
		
		ArrayList<Map<String,String>> map_data = new ArrayList<Map<String,String>>();

		this.execQuery(qry);
		ResultSet result = this.rs;

		try {
			if (result != null) {
				ResultSetMetaData rsmd = result.getMetaData();
				int getColumnCount = rsmd.getColumnCount();

				for (int i = 1; i <= getColumnCount; i++) {
					columns.add(rsmd.getColumnName(i));
				}
				if (!result.next()) {
					System.out.println("no data");
				} else {

					do {
						
						Map<String,String> row_data = new HashMap<String,String>();
						for (int i = 1; i <= getColumnCount; i++) {
							Object col_val = result.getObject(i);
							String col_val_str = "";
							if(col_val != null){
								col_val_str = col_val.toString();
							}
							row_data.put(rsmd.getColumnName(i), col_val_str);
						}
						map_data.add(row_data);
					} while (result.next());
				}
			}
			this.conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return map_data;
	}
	
	
}
