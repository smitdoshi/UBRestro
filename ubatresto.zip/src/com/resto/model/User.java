package com.resto.model;

import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Map;

import com.mysql.jdbc.Statement;

public class User extends ModelArchive {

	public Map<String, ArrayList> getData() {
		Map<String, ArrayList> list = this.getFormattedData("select * from user",true);
		return list;
	}
	
	public ArrayList<Map<String,String>> getUserDataByQry(String query,boolean header) {
		ArrayList<Map<String,String>> data = this.getKeyValByRow(query);
		return data;
	}

	public Map <String,String> create_user(Map<String, String> data) {
		Map <String,String> error_data = new HashMap<String,String>();
		int error = 1;
		try {
			data.remove("confirm_password");
			String insert_str = "INSERT INTO user "
					+ "(birth_date,email,first_name,gender,images,last_name,login_name,password,phone,user_type)"
					+ " values(?,?,?,?,?,?,?,?,?,?)";
			int param_count = 1;

			this.connectToDb();
			PreparedStatement ps;
			System.out.println(data);
			ps = ((java.sql.Connection) this.conn).prepareStatement(insert_str);

			for (Map.Entry<String, String> entry : data.entrySet()) {

				String key = entry.getKey();
				
				String value = entry.getValue();
				System.out.println(key+ " "+value);
				ps.setString(param_count, value);
				param_count++;
			}
			ps.execute();
			error =0;
			this.conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		}
		error_data.put("error_status", Integer.toString(error));

		return error_data;
	}
	
	public void get_user_order_detail(){
		
	}
	
	public void updateLoginIp(String user_id,String ip_address){
		String qry = "SELECT * FROM user WHERE id="
				+user_id + " LIMIT 1;";


		ArrayList<Map<String, String>> item_entry = this.getKeyValByRow(qry);

		this.connectToDb();
		PreparedStatement ps;
		if (item_entry.size() > 0) {

			String insert_str = "UPDATE user SET login_ip = ? where id=" + user_id+ ";";
			try {
				ps = ((java.sql.Connection) this.conn).prepareStatement(insert_str, Statement.RETURN_GENERATED_KEYS);
				ps.setString(1, ip_address);
				ps.executeUpdate();
			} catch (SQLException e) {
				System.out.println(e);
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	} 
}
